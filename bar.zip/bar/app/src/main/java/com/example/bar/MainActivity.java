package com.example.bar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    SeekBar bar;
    SeekBar barr;
    TextView acreditar;
    TextView tbar1;
    TextView tbar2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bar = (SeekBar) findViewById(R.id.sbar1);
        barr = (SeekBar) findViewById(R.id.sbar2);
        acreditar = (TextView) findViewById(R.id.acred);
        tbar1 = (TextView) findViewById(R.id.bar1);
        tbar2 = (TextView) findViewById(R.id.bar2);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                   tbar1.setText(progress+"");
                tbar1.setText(progress+"");
                if (progress <= barr.getProgress()) {
                    acreditar.setText("acreditado");
                }else{
                    acreditar.setText("no acreditado");

                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });
        barr.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tbar2.setText(progress+"");
                if (progress >= bar.getProgress()) {
                    acreditar.setText("acreditado");
                }else{
                    acreditar.setText("no acreditado");

                    }
                }


            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });


    }
}
