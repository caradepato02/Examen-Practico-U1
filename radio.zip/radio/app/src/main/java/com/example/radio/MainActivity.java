package com.example.radio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

        SeekBar seekBar;
        TextView textView3;
        Button btn1;
        EditText ed1;
        Double v;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        textView3 = (TextView) findViewById(R.id.textView3);
        seekBar = (SeekBar) findViewById(R.id.seekBar);



        btn1 =(Button) findViewById(R.id.btn1);
        ed1 =(EditText) findViewById(R.id.ed1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                v = (((2.0/3.0)*((Double.valueOf(seekBar.getProgress())))*(((Double.valueOf(ed1.getText().toString())*(Double.valueOf(ed1.getText().toString())*(Double.valueOf(ed1.getText().toString()))))))));
                Toast toast1 =
                        Toast.makeText(getApplicationContext(),
                                "El volumen es " + v, Toast.LENGTH_SHORT);

                toast1.show();
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                seekBar.setMax(360);
                textView3.setText(progress+"");


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}
