package com.example.eva1_examen_ahorcado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    Button btnIntentar;
    Button btnAceptar;
    Ahorcado ahorcado;
    TextView txtVwPalabra;
    EditText editLetra;
    RadioGroup radGupo;
    TextView txtVwIntentos;
    TextView txtVwLetrasnum;
    CheckBox checkXtream;
    int radioDif;
    boolean xtream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Resources res = getResources();
        ahorcado = new Ahorcado(res.getStringArray(R.array.palabras));
        btnIntentar = findViewById(R.id.btnIntentar);
        btnAceptar = findViewById(R.id.btnAceptar);
        txtVwPalabra = findViewById(R.id.txtVwPalabra);
        editLetra = findViewById(R.id.editLetra);
        radGupo = findViewById(R.id.rgGrupo);
        txtVwIntentos = findViewById(R.id.txtVwIntentosNum);
        txtVwLetrasnum = findViewById(R.id.txtVwCantidadNum);
        checkXtream = findViewById(R.id.checkXtream);
        ahorcado.setDificultad(1);
        checkXtream.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                xtream = isChecked;
            }
        });

        radGupo.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbFacil:
                        radioDif= 1;
                        break;
                    case R.id.rbMedio:
                        radioDif= 2;
                        break;
                    case R.id.rbdificil:
                        radioDif= 3;
                        break;

                }
            }
        });



        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String palabra;
                String valor = editLetra.getText().toString();
                if(valor.length() == 1){
                    palabra = ahorcado.revelarLetra(valor.charAt(0));
                    txtVwPalabra.setText(palabra);
                }else{
                    txtVwPalabra.setText(ahorcado.adividarPalabra(valor));
                }

                txtVwIntentos.setText(String.valueOf(ahorcado.getIntentos()));
                switch(ahorcado.checkStatus()){
                    case 1:
                        Toast.makeText(getApplicationContext(), "Perdiste", Toast.LENGTH_LONG).show();
                        break;
                    case 2:
                        Toast.makeText(getApplicationContext(), "Ganaste", Toast.LENGTH_LONG).show();
                        break;
                }
                editLetra.setText("");
            }
        });

        btnIntentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { editLetra.setText("");

                ahorcado.iniciar();
                ahorcado.setXtrem(xtream);
               txtVwPalabra.setText(ahorcado.ocultar());
               ahorcado.setDificultad(radioDif);
               txtVwIntentos.setText(String.valueOf(ahorcado.getIntentos()));
               txtVwLetrasnum.setText(String.valueOf(ahorcado.getCantidadLetras()));

            }
        });
    }


}
