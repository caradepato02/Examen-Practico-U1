package com.example.eva1_examen_ahorcado;

import android.content.res.Resources;

public class Ahorcado {

    private int intentos = 0;
    private int cantidadLetras;
    private int dificultad = 1;
    private String palabraActual;
    private StringBuilder palabraOculta;
    private String[] palabras;
    private boolean ganar = false;
    private boolean perder = false;
    private boolean xtrem = false;


    public Ahorcado(String[] palabras) {
        this.palabras = palabras;

    }

    public void iniciar(){
        ganar = false;
        perder = false;
        int ran = (int)(Math.random()*9);
        this.palabraActual = palabras[ran];
        this.palabraOculta = new StringBuilder(palabraActual);
        this.cantidadLetras = palabraActual.length();
    }

    public String ocultar(){
        for(int i = 0; i < palabraActual.length() ;i++){
            palabraOculta.setCharAt(i,'_');
        }
        return palabraOculta.toString();
    }

    public String revelarLetra(char letra){
        String copia = palabraOculta.toString();
        for(int i = 0; i < palabraActual.length() ;i++){
            if ( letra == palabraActual.charAt(i)){
                if (xtrem){
                    switch(letra){
                        case 'a':
                        case 'e':
                        case 'i':
                        case 'o':
                        case 'u':
                            intentos--;
                            break;
                    }
                }
                palabraOculta.setCharAt(i,letra);
            }
        }
        if (copia.equals(palabraOculta.toString())){
            intentos--;
        }
        if (palabraActual.equals(palabraOculta.toString())){
            ganar = true;
        }

        return palabraOculta.toString();
    }

    public String adividarPalabra(String palabra){
        if (palabra.equals(palabraActual)){
            ganar = true;
            return palabraActual;

        }else{
            perder = true;
            return palabraOculta.toString();
        }
    }

    public int checkStatus(){
        if (intentos <= 0){
            perder = true;
        }
        if (ganar){
            ganar = true;
            return 2;
        }else if (perder){
            perder = false;
            return 1;
        }
        return 0;
    }


    public void setDificultad(int dificultad){
        switch (dificultad){
            case 1: intentos = 6;
                break;
            case 2: intentos = 4;
                break;
            case 3: intentos = 2;
                break;
        }
        this.dificultad = dificultad;
    }

    public int getDificultad() {
        return dificultad;
    }


    public String getPalabraActual() {
        return palabraActual;
    }

    public void setPalabraActual(String palabraActual) {
        this.palabraActual = palabraActual;
    }

    public String[] getPalabras() {
        return palabras;
    }

    public void setPalabras(String[] palabras) {
        this.palabras = palabras;
    }

    public int getIntentos() {
        return intentos;
    }

    public int getCantidadLetras() {
        return cantidadLetras;
    }

    public void setXtrem(boolean xtrem) {
        this.xtrem = xtrem;
    }
}
